<template>
  <div>
      我是Register
  </div>  
</template>

<script>
export default {

}
</script>

<style>

</style>